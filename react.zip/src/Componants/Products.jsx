import * as React from 'react';
import { styled } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import Breadcrumbs from '@mui/material/Breadcrumbs';
import Link from '@mui/material/Link';
import HomeIcon from '@mui/icons-material/Home';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Modal from '@mui/material/Modal';
import TextField from '@mui/material/TextField';
// import Stack from '@mui/material/Stack';

import axios from 'axios';
// import { useScrollTrigger } from '@mui/material';

// const VisuallyHiddenInput = styled('input')({
//   clip: 'rect(0 0 0 0)',
//   clipPath: 'inset(50%)',
//   height: 1,
//   overflow: 'hidden',
//   position: 'absolute',
//   bottom: 0,
//   left: 0,
//   whiteSpace: 'nowrap',
//   width: 1,
// });


const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 700,
  bgcolor: 'background.paper',
  border: '2px solid #000',
  boxShadow: 24,
  p: 4,
};

function handleClick(event) {
  event.preventDefault();
  console.info('You clicked a breadcrumb.');
}

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: theme.palette.common.black,
    color: theme.palette.common.white,
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
  },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  '&:nth-of-type(odd)': {
    backgroundColor: theme.palette.action.hover,
  },
  // hide last border
  '&:last-child td, &:last-child th': {
    border: 0,
  },
}));

// function createData(name, calories, fat, carbs, protein) {
//   return { name, calories, fat, carbs, protein };
// }

// const rows = [
//   createData('Frozen yoghurt', 159, 6.0, 24, 4.0),
//   createData('Ice cream sandwich', 237, 9.0, 37, 4.3),
 
// ];




export default function Products() {

  const [getdata, setgetData] = React.useState([]);
  // const [newdata, setnewData] = React.useState([]);

  const[id, setId] = React.useState();

    const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  let [data,setData] = React.useState({
     name:"",
     price:0,
     mrp:0,
     gstpercent:0,
     image:""
  });

  function handelData(e) {
    e.preventDefault();
    setData({ ...data, [e.target.id]: e.target.value });
  }

  function handleSubmit(){
if(id===undefined){
     data ={
        name :data.name,
        price: data.price,
        mrp:data.mrp,
        gstpercent:data.gstpercent,
        image:data.image
    }
    console.log(data);
    
        axios.post("http://localhost:8081/products", data)
          .then((res) => {
            
            console.log(res.data);

          })
        }else{
          axios.put("http://localhost:8081/products/"+id,data)
          .then((res)=>{
            console.log(res.data);
            getloadData()
          });
          setData({
            name:"",
            price:0,
            mrp:0,
            gstpercent:0,
            image:""
          })
        }
  }

  function getloadData(){
   axios.get("http://localhost:8081/products")
   .then((res)=>{
    console.log(res.data.data);
    setgetData(res.data.data)

   })
  }
  React.useEffect(()=>{
    getloadData();
  }, []);



   function handleUpdate(e,id){
    setId(id)
    e.preventDefault();
    handleOpen();
    axios.get("http://localhost:8081/products/"+ id)
    .then((res) => {
      console.log(res.data);

      setData({
        name :res.data.name,
        price: res.data.price,
        mrp:res.data.mrp,
        gstpercent:res.data.gstpercent,
        image:res.data.image
      })
    }).catch((err)=>{
      console.log(err);
     
    })
    // setnewData(newdata);
    // getloadData()
   };



   function handleDelete(e,id){
    e.preventDefault();
    axios.delete("http://localhost:8081/products/"+id)
    .then((res)=> {
      console.log(res.data.data);
      getloadData()
    })
    console.log(id);
   }


  return (

// breadcrumbs

<>


<div role="presentation" onClick={handleClick}>
      <Breadcrumbs aria-label="breadcrumb"  style={{fontSize:"28px"}}>
        <Link
          underline="hover"
          sx={{ display: 'flex', alignItems: 'center' }}
          color="black"
          href="/"
        >
          <HomeIcon sx={{ mr: 0.5 }} fontSize="inherit" />
          <h1>Products</h1>
        </Link>
       
       {/* modal */}
    
       <div>
      <Button onClick={handleOpen} style={{fontSize:"32px",backgroundColor:"black",color:"ButtonHighlight",marginLeft:"80rem"}}>+</Button>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          
        {/* //modal form */}

        <TextField onChange={handelData}
          required
          id="name"
          label="Name"
          value={data.name}
          type="text"
          size='medium'
          sx={{ width: '100%' }} 
          variant="standard"
        />

           <TextField onChange={handelData}
          required
          id="mrp"
          label="mrp"
          value={data.mrp}
          type="number"
          size='medium'
          sx={{ width: '100%' }} 
          variant="standard"
        />

        <TextField onChange={handelData}
          required
          id="price"
          label="price"
          value={data.price}
          type="number"
          size='medium'
          sx={{ width: '100%' }} 
          variant="standard"
        />

        <TextField onChange={handelData}
          required
          id="gstpercent"
          label="gstpercent"
          value={data.gstpercent}
          type="number"
          size='medium'
          sx={{ width: '100%' }} 
          variant="standard"
        />

        <TextField onChange={handelData}
          required
          id="image"
          label="image"
          value={data.image}
          type="file"
          size='medium'
          sx={{ width: '100%' }} 
          variant="standard"
        />
         

         <button onClick={handleSubmit}>Submit</button>
        </Box>
      </Modal>
    </div>
    
    
      </Breadcrumbs>

    </div>

    <TableContainer component={Paper}>
      <Table sx={{ minWidth: 700 }} aria-label="customized table">
        <TableHead>
          <TableRow>
          
            <StyledTableCell>Name</StyledTableCell>
            <StyledTableCell align="right">MRP</StyledTableCell>
            <StyledTableCell align="right">Price</StyledTableCell>
            <StyledTableCell align="right">GST %</StyledTableCell>
            <StyledTableCell align="right">Image</StyledTableCell>
        
          </TableRow>
        </TableHead>
         <TableBody>
          {
          getdata.map((eachdata,i) => {
            return( 
            <StyledTableRow key={i}>
              <StyledTableCell component="th" scope="row">
                {i+1}
              </StyledTableCell>
              <StyledTableCell align="right">{eachdata.name}</StyledTableCell>
              <StyledTableCell align="right">{eachdata.mrp}</StyledTableCell>
              <StyledTableCell align="right">{eachdata.price}</StyledTableCell>
              <StyledTableCell align="right">{eachdata.gstpercent}</StyledTableCell>
              {/* <StyledTableCell img src="" align="right">{eachdata.image} </StyledTableCell> */}

              <button className='btn btn-primary me-3'onClick={((e)=>handleUpdate(e,eachdata._id))} style={{fontSize:"18px",marginLeft:"5rem"}}>Edit</button>

              <button className='btn btn-primary me-3'onClick={((e)=>handleDelete(e,eachdata._id))} style={{fontSize:"18px",marginLeft:"1rem"}} >Delete</button>
            </StyledTableRow>
             )
            })} 
        </TableBody> 
      </Table>
    </TableContainer>
    </>
  )
  }

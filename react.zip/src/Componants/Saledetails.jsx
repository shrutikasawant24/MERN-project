import axios from 'axios'
import React, { useEffect, useState } from 'react'

export default function Saledetails() {

    const [saledetails , setSaledetails] = useState([{
        productid:"",
        price:"",
        quantity:"",
        subtotal:"",
        gstpercent:"",
        gsttotal:"",
        grandtotal:""
    }]);

function loadData(){
    axios.get("http://127.0.01:8081/sales/")
    .then((res) => {
        console.log(res.data.data);
        setSaledetails(res.data.data)
    }).catch((err) =>{
        console.log(err);
    })
}useEffect(()=>{
    loadData()
},[])

  return (
    <div>Saledetails

<div>
            {/* Render your saledetails data here */}
            {saledetails.map((sale, index) => (
                <div key={index}>
                    <div>Product ID: {sale.productid}</div>
                    <div>Price: {sale.price}</div>
                    <div>Quantity: {sale.quantity}</div>
                    {/* Add more fields as needed */}
                </div>
            ))}
        </div>
        
    </div>
  )
}

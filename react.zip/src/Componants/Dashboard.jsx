import * as React from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import { CardActionArea } from '@mui/material';

export default function Dashboard() {
  return (
    <div className="container" >
      <div className="row"  style={{display:"flex"}}>
        <div className="col-lg-3" >
    <Card sx={{ maxWidth: 500 }} style={{ marginLeft:"5rem", marginTop:"3rem"}}>
      <CardActionArea>
         {/* <CardMedia
          component="img"
          height="180"
          image="/static/images/cards/contemplative-reptile.jpg"
          alt="green iguana"
          
        />  */}
        
        <CardContent>
        <i class="fa-solid fa-user" style={{fontSize:"45px", marginLeft:"3rem"}}></i>
          <Typography gutterBottom variant="h5" component="div">
            <h1>Users</h1>
          </Typography>
          {/* <Typography variant="body2" color="text.secondary">
            Lizards are a widespread group of squamate reptiles, with over 6,000
            species, ranging across all continents except Antarctica
          </Typography> */}
        </CardContent>
      </CardActionArea>
    </Card>
    </div>

    <div className="col-lg-3">
    <Card sx={{ maxWidth: 445 }} style={{marginLeft:"5rem",marginTop:"3rem"}}>
      <CardActionArea>
        {/* <CardMedia
          component="img"
          height="180"
          image="/static/images/cards/contemplative-reptile.jpg"
          alt="green iguana"
        /> */}
        <CardContent>
          <Typography gutterBottom variant="h5" component="div">
            <h1>Products</h1>
          </Typography>
          {/* <Typography variant="body2" color="text.secondary">
            Lizards are a widespread group of squamate reptiles, with over 6,000
            species, ranging across all continents except Antarctica
          </Typography> */}
        </CardContent>
      </CardActionArea>
    </Card>
    </div>

    </div>

    <div className="row"  style={{display:"flex"}}>
        <div className="col-lg-3" >
    <Card sx={{ maxWidth: 445 }} style={{marginLeft:"5rem", marginTop:"3rem"}}>
      <CardActionArea>
        {/* <CardMedia
          component="img"
          height="180"
          image="/static/images/cards/contemplative-reptile.jpg"
          alt="green iguana"
        /> */}
        <CardContent>
          <Typography gutterBottom variant="h5" component="div">
            <h1>Sales</h1>
          </Typography>
          {/* <Typography variant="body2" color="text.secondary">
            Lizards are a widespread group of squamate reptiles, with over 6,000
            species, ranging across all continents except Antarctica
          </Typography> */}
        </CardContent>
      </CardActionArea>
    </Card>
    </div>

    <div className="col-lg-3">
    <Card sx={{ maxWidth: 445 }} style={{marginLeft:"5rem", marginTop:"3rem"}}>
      <CardActionArea>
        {/* <CardMedia
          component="img"
          height="180"
          image="/static/images/cards/contemplative-reptile.jpg"
          alt="green iguana"
        /> */}
        <CardContent>
          <Typography gutterBottom variant="h5" component="div">
            <h1>Sale Details</h1>
          </Typography>
          {/* <Typography variant="body2" color="text.secondary">
            Lizards are a widespread group of squamate reptiles, with over 6,000
            species, ranging across all continents except Antarctica
          </Typography> */}
        </CardContent>
      </CardActionArea>
    </Card>
    </div>

    </div>

    </div>
    


  );
}
import React, {  useEffect, useState } from 'react'
// import { styled } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import Breadcrumbs from '@mui/material/Breadcrumbs';
import Link from '@mui/material/Link';
import { Box,Button } from '@mui/material';
import Grid from '@mui/material/Grid';

// import TextField from '@mui/material/TextField';
import { TextField } from '@mui/material';
import axios from 'axios';



import {Select, MenuItem} from "@mui/material";





export default function Sales() {


//quantity
// let[quantity,setQuantity]=useState(1);

 //let[subtotal,setSubtotal]=useState(0);

//bill
//let[billtotal,setBillTotal]=useState(0);

//get products getting data in array from db
let [product,setProduct]=useState([]); 



//custm details
let [custdet,SetCustDet]=useState({});

let[saleProducts,setSaleProducts]=useState([{
  quantity:1,

}]);



//customer detail like mob,name
function handlecustdet(e)
{
SetCustDet({...custdet,[e.target.id]:e.target.value})
}
//onchnge handle on selected product drop menu

function handleSelectProduct(id,i){

  console.log(id);
  let selectedProduct=product.find((e)=>e._id === id);
  let copyRows=[...saleProducts];
  copyRows[i]=selectedProduct;










  
  setSaleProducts(copyRows); 
 
  // console.log(selectedProduct);
 
  
}
console.log(saleProducts);







function changingquantity(i,e)
{
  let updatesaleproduct=[...saleProducts];
  updatesaleproduct[i].quantity=e;
  setSaleProducts(updatesaleproduct);
 

}

console.log(saleProducts);




//add row
function addrow(){

setSaleProducts([...saleProducts,{}])
  
}
// console.log('saleProducts:', saleProducts); 
// console.log('products',product);









useEffect(()=>{
   
  //updateSubtotal();
  onload();
},[])



//getting product data
function onload(){


  axios.get("http://127.0.0.1:8081/products/")
  
      .then((resp)=>{
        console.log(resp.data);
        setProduct(resp.data.data);

      })
      .catch((error)=>{
        console.log(error);

      });

 
    }

console.log(product);
console.log(saleProducts);
 
  



console.log('salproduct',saleProducts);
console.log('custde',custdet);

//function send sale data
function saledata(e){
  let updatesaleproduct=saleProducts.map((item)=>({
    ...item,
    subtotal:item.price*item.quantity,
    gsttotal:(item.price*item.quantity*item.gstpercent)/100,
    billtotal:(item.price*item.quantity) +((item.price* item.quantity*item.gstpercent)/100),

  }));

  const postData={
    saleProducts:updatesaleproduct,
    custdet,
    
  
}
console.log(postData);
  axios.post("http://127.0.0.1:8081/sales",postData)
  .then((res)=>{
    console.log(res.data);
    onload();

  }).catch((err)=>{
    console.log(err);
  })
}





  return (
    <>
    <form> 
     {/* onSubmit={saledata}  */}
    {/* //grid  */}
    <Grid container spacing={2}>
  <Grid item xs={10} >
    
  {/* //breadcrumb */}
<div role="presentation" >
      <Breadcrumbs aria-label="breadcrumb">
        <Link underline="hover" color="inherit" href="/">
          Dashboard
        </Link>
        <Link
          underline="hover"
          color="inherit"
          href="/material-ui/getting-started/installation/"
        >
          Sales
        </Link>
  
      </Breadcrumbs>
       
     
    </div>
    {/* end breadcrumb */}
   </Grid>
   {/* datepicker */}
   <Grid container spacing={3}>
  <Grid item xs={4}>
  <TextField
              margin="normal"
              required
              fullWidth

              id="date"
              // label="date"
              type="date"
              name="date"
              // value={cdate}
              // autoComplete="date"
              // autoFocus
              onChange={((e)=>handlecustdet(e))}            />

  </Grid>
  <Grid item xs={4}>
     <TextField
              margin="normal"
              required
              fullWidth

              id="cname"
              label="Name"
              type="text"
              name="cname"
              // value={cname}
              // autoComplete="cname"
              // autoFocus
              onChange={((e)=>handlecustdet(e))}            />
  </Grid> 
  <Grid item xs={4}>
     <TextField
              margin="normal"
              required
              fullWidth

              id="cmobileno"
              label="Mobileno"
              type="number"
              name="cmobileno"
              // value={cmobileno}
              // autoComplete="cmobileno"
              // autoFocus
              onChange={((e)=>handlecustdet(e))}            />
  </Grid> 

  </Grid>
   
   
  
   </Grid>

   {/* table */}
   <>
   <Button onClick={addrow}>Add row</Button>
   {/* <Button onClick={handleAddProduct}>add Product</Button> */}
   </>
   <TableContainer component={Paper}>
  <Table>
 
    <TableHead>
      <TableRow >
        <TableCell>Id </TableCell>
        <TableCell>Product Name </TableCell>
        <TableCell  >MRP </TableCell>
        <TableCell>Price </TableCell>
        <TableCell>Quantity </TableCell>
        <TableCell>SubTotal </TableCell>
        <TableCell>GstPercent </TableCell>
        <TableCell>GstTotal </TableCell>
        <TableCell>BillTotal </TableCell>


      </TableRow>
    </TableHead>
    <TableBody>
      
     {saleProducts.map((pitem,index)=>{
      // let cal = pitem.price*quantity
      return( 
      
        <TableRow  key={index}>
          <TableCell scope='row'> {index+1}   </TableCell>
          <TableCell>
          <Select
            
           onChange={(e)=>handleSelectProduct(e.target.value,index)}
           >
        <MenuItem value="">select product</MenuItem>
        {product.map((prod)=>(
          
        <MenuItem key={prod._id} value={prod._id}>{prod.name}</MenuItem>
        ))}
        


       
      </Select>

          </TableCell>
        
             <TableCell >
          <TextField
              id="mrp"
              value={pitem.mrp}
              //onChange={handleSelectProduct}
              type="number"
              
              /> 
        {/* {selectedProduct && (
              <div>
            {product.find(prod=> prod._id === selectedProduct)?.mrp}
              </div>
            )} */}
          </TableCell>
          <TableCell>
          < TextField
              id="price"
              value={pitem.price}

             
              type="number"
              name="price"
              
             
         />
          
       
              
          </TableCell>
          
          <TableCell>
          <TextField
              id="quantity"
              value={pitem.quantity}
              type="number"
              name="quantity"
              onChange={(e)=>changingquantity(index,e.target.value)}
              
            />
          </TableCell>
          <TableCell>
          <TextField
              
              id="subtotal"
              value={parseFloat(pitem.price * pitem.quantity)}
              type="number"
              name="subtotal"
          
            />
          </TableCell>
          <TableCell>
          <TextField

              id="gstpercent"
             value={pitem.gstpercent} 
              type="number"
              name="gstpercent"
              
            />
          </TableCell>
          <TableCell>
          <TextField
            

             
              id="gsttotal"
              value={(pitem.price*pitem.quantity)*pitem.gstpercent/100  }
              type="number"
              
              
              
            
            />
            
          </TableCell>
          <TableCell>
          <TextField
           

              id="billtotal"
             value={(pitem.price*pitem.quantity)*pitem.gstpercent/100+ (pitem.price * pitem.quantity)}
              type="number"
              name="billtotal"
             
            />
          </TableCell>
          {/* <TableCell><Button onClick={handleSubmit}>edit</Button> <Button>Del</Button></TableCell> */}
          
        </TableRow>
       )
          })}
          
       
    </TableBody>
  </Table>
  
</TableContainer>


  <Box><Button type='submit' onClick={saledata} variant='contained' color='primary'>Submit</Button>
 


  </Box>

  </form>
    </>
  )
}
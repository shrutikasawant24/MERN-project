import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
// import FormControlLabel from "@mui/material/FormControlLabel";
// import Checkbox from "@mui/material/Checkbox";
import Link from "@mui/material/Link";
// import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Container from "@mui/material/Container";
import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
// import { useState } from "react";
// import Stack from '@mui/material/Stack';
// import axios from "axios";

export default function Login() {


const [email, setEmail] = useState()
const [password, setPassword] = useState()

const navigate = useNavigate()





   const handleSubmit = (event) => {
   event.preventDefault();
     axios.get('http://127.0.01:8081/users' , { email, password})
    //  .then(result => console.log(result))
    //  .catch(err => console.log(err))
      .then((res) => {
        console.log(res.data);
        navigate('/dashboard')
      }).catch((res)=>{
        console.log(res.data);
      })
  };


  return (
    <Container component="main" maxWidth="xs">
      <Box
        sx={{  
          marginTop: 8,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <Typography component="h1" variant="h5">
          Sign in
        </Typography>
        <Box component="form" noValidate sx={{ mt: 1 }} onSubmit={handleSubmit}>

          <TextField
          onChange={(e) => setEmail(e.target.value)}
            margin="normal"
            required
            fullWidth
            id="email"
            type="text"
            label="Email Address"
            name="email"
            autoComplete="email"
            autoFocus
          />
          <TextField
          onChange={(e) => setPassword(e.target.value)}
            margin="normal"
            required
            fullWidth
            name="password"
            label="Password"
            type="password"
            id="password"
            autoComplete="current-password"
          />
          {/* <FormControlLabel
            control={<Checkbox value="remember" color="primary" />}
            label="Remember me"
          /> */}

<Button variant="contained" href="#contained-buttons">
        Register
      </Button>
      <p>Already have an Account ?</p>
          
          <Link to= "/login">
          <Button
            type="submit"
            fullWidth
            variant="contained"
            sx={{ mt: 3, mb: 2 }}
          >
            Login
          </Button>
          </Link>

          {/* <Grid container>
            <Grid item xs>
              <Link href="#" variant="body2">
                Already have an Account ?
              </Link>
            </Grid>
            <Grid item>
              <Link href="#" variant="body2">
                {"Don't have an account? Sign Up"}
              </Link>
            </Grid>
          </Grid> */}
        </Box>
      </Box>
    </Container>
  );
}
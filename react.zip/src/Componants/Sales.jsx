import React, { useEffect, useState } from 'react'
import { styled } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import {Select, MenuItem} from "@mui/material";
import axios from 'axios';
import TextField from '@mui/material/TextField';
import { Box,Button } from '@mui/material';
import { Link } from 'react-router-dom';

const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
      backgroundColor: theme.palette.common.black,
      color: theme.palette.common.white,
    },
    [`&.${tableCellClasses.body}`]: {
      fontSize: 14,
    },
  }));
  
  const StyledTableRow = styled(TableRow)(({ theme }) => ({
    '&:nth-of-type(odd)': {
      backgroundColor: theme.palette.action.hover,
    },
    // hide last border
    '&:last-child td, &:last-child th': {
      border: 0,
    },
  }));

export default function Sales() {

// let [sales, setSales] = useState([])
let [customer, setCustomer] = useState({
  // cdate:"",
  // cname:"",
  // cmobileno:""
});

  let [product,setProduct]=useState({});


function getloadData(){
  axios.get("http://127.0.0.1:8081/products/")
  
      .then((res)=>{
        console.log(res.data.data);
        setProduct(res.data.data);

      })
      .catch((error)=>{
        console.log(error);
      })
    } useEffect(()=>{
      getloadData()
    },[]);


const [rows, setRows] = useState([{quantity:1}])

    const addrow =()=>{
    let copyRows = [...rows]
    copyRows.push({quantity:1})
    setRows(copyRows)
    }

    console.log(rows);

    //select product
    function handleSelect (name,i){
       let drop = product.find((e) => (e._id ===name));
       let sales = [...rows]
       sales[i] = {...drop,quantity:1}
       setRows(sales)
       console.log(drop);
    }

    // change quantity
    function handleQuantity(index,value){
     const updaterow = [...rows];
     updaterow[index].quantity = value;
      setRows(updaterow);
    }

    //customer details
    function handlecust(e){
      e.preventDefault();
      setCustomer({ ...customer, [e.target.id]: e.target.value });
     
    }

    // post data
    function handleSubmit(){
      let data = {
        customer: {
          cname: customer.cname,
          cdate: customer.cdate,
          cmobileno: customer.cmobileno,
        },
        product: rows,
      }

    console.log(customer);

    axios.post("http://127.0.01:8081/sales",data)
    .then((res) => {
      console.log(res.data);
      setProduct(res.data.data)
    }).catch((err) => {
      console.log(err);
    })
  }
  

  return (
    <>

<Box
      component="form"
      sx={{
        '& > :not(style)': { m: 1, width: '55ch' },
      }}
      noValidate
      autoComplete="off"
    >
      <TextField id="sdate" onChange={handlecust} type='date' variant="outlined" />
      <TextField id="cname" type='text' onChange={handlecust} label="name" variant="outlined" />
      <TextField id="cmobileno" type='text' onChange={handlecust} label="mobile No." variant="outlined" />
      
    </Box>

    <Button onClick={addrow}>Add row</Button>

      <TableContainer component={Paper} style={{marginTop:"2rem",}}>
        <Table sx={{ minWidth: 200 }} aria-label="customized table">
          <TableHead >
            <TableRow style={{alignContent:"center"}}>
              <StyledTableCell>Name</StyledTableCell>
              <StyledTableCell align="right">Price</StyledTableCell>
              <StyledTableCell align="right">MRP</StyledTableCell>
              <StyledTableCell align="right">quantity</StyledTableCell>
              <StyledTableCell align="right">subtotal</StyledTableCell>
              <StyledTableCell align="right">GST %</StyledTableCell>
              <StyledTableCell align="right">gsttotal</StyledTableCell>
              <StyledTableCell align="right">Bill-Total</StyledTableCell>



            </TableRow>
          </TableHead>
          <TableBody>
    {rows.map((row,index)=>{
        return(
            <StyledTableRow> 
            <StyledTableCell component="th" scope="row">
              <Select onChange={(e) => handleSelect(e.target.value,index)}
              
                style={{ marginTop:"50px", marginLeft:"30px" }}
              >
              {product.map((prods, i) => (
              
                  <MenuItem key={i} value={prods._id}> {prods.name} </MenuItem>
                  ))}
              </Select>
              
            </StyledTableCell>
            {/* Add other cells here */}
            <StyledTableCell>
            <TextField id="price" type='number'  variant="outlined" value={row.price}/>
            </StyledTableCell>
          
            <StyledTableCell>
            <TextField id="mrp" type='number'  variant="outlined" value={row.mrp}/>
            </StyledTableCell>
          
            <StyledTableCell>
            <TextField id="quantity" type='number' variant="outlined" onChange={(e) => handleQuantity(index,e.target.value)} value={row.quantity}/>
            </StyledTableCell>
          
            <StyledTableCell>
            <TextField id="subtotal" type='number'  variant="outlined"  value={row.name ? row.price *row.quantity :""} />
            </StyledTableCell>
          
            <StyledTableCell>
            <TextField id="gstpercent" type='number' variant="outlined" value={row.gstpercent} />
            </StyledTableCell>
          
            <StyledTableCell>
            <TextField id="gsttotal" type='number' variant="outlined" value={row.name ? row.price * row.gstpercent/100 * row.quantity :""} />
            </StyledTableCell>
          
            <StyledTableCell>
            <TextField id="billtotal" type='number' variant="outlined" value={ row.name ? row.price * row.gstpercent/100 * row.quantity + row.price *row.quantity: ""} />
            </StyledTableCell>
          
          </StyledTableRow>


        )
    })}
      
          </TableBody>
        </Table>
      </TableContainer>

   
      <Button variant="contained" onClick={(e) => handleSubmit(e.target.value)} style={{alignItems:"flex-end", marginTop:"2rem"}}>Order Now</Button>
  
    
    </>
  )
}
